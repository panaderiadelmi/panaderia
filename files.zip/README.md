# 🍞 PANADERÍA SEÑAS GÓMEZ - Web Escalable
## Sistema Modular Completamente Funcional

---

## ✨ CARACTERÍSTICAS PRINCIPALES

### 🎯 **TOTALMENTE ESCALABLE**
- **Un solo archivo de configuración** (`data/config.json`) controla TODA la web
- Añadir/modificar productos, usuarios, categorías → **Sin tocar código**
- Cambiar colores, textos, horarios → **Solo editar JSON**
- Arquitectura modular: cada componente es independiente

### 🛒 **E-COMMERCE FUNCIONAL**
- ✅ Carrito de compras completo
- ✅ Sistema de stock en tiempo real
- ✅ Descuentos y ofertas
- ✅ Filtrado y ordenamiento de productos
- ✅ Categorización dinámica

### 🔐 **SISTEMA DE USUARIOS ROBUSTO**
- 5 Roles predefinidos: Admin, Tienda, Maestro, Cliente, Invitado
- Permisos granulares por rol
- Login/Registro funcional
- Credenciales de prueba incluidas

### 📱 **100% RESPONSIVE**
- Diseño adaptativo móvil/tablet/desktop
- Animaciones suaves
- Micro-interacciones

---

## 📁 ESTRUCTURA DEL PROYECTO

```
panaderia-senas-gomez/
│
├── index.html                  # HTML principal (NO tocar)
│
├── data/
│   └── config.json            # ⭐ ARCHIVO MAESTRO - EDITA AQUÍ
│
├── css/
│   └── styles.css             # Estilos (variables CSS dinámicas)
│
├── js/
│   ├── config.js              # Carga config.json
│   ├── auth.js                # Sistema de autenticación
│   ├── cart.js                # Carrito de compras
│   ├── products.js            # Gestión de productos
│   ├── ui.js                  # Utilidades UI
│   └── main.js                # Orquestador principal
│
└── README.md                  # Esta guía
```

---

## 🚀 CÓMO USAR (SIN PROGRAMAR)

### 1️⃣ **AÑADIR UN PRODUCTO**

Abre `data/config.json` y añade en el array `products`:

```json
{
  "id": 17,
  "name": "Pan de Ajo",
  "category": "panaderia",
  "description": "Pan rústico con ajo y perejil",
  "price": 2.50,
  "weight": "300g",
  "icon": "🧄",
  "ingredients": ["Harina", "Ajo", "Perejil"],
  "allergens": ["Gluten"],
  "featured": true,
  "inStock": true,
  "stock": 20,
  "discount": 0
}
```

**¡LISTO!** Se muestra automáticamente en la web.

### 2️⃣ **CAMBIAR COLORES**

En `config.json` → sección `theme`:

```json
"theme": {
  "primaryColor": "#2C5F2D",     // Verde oscuro
  "secondaryColor": "#FFD93D",   // Amarillo dorado
  "accentColor": "#6BCB77",      // Verde claro
  ...
}
```

Guarda → Los colores cambian en TODA la web automáticamente.

### 3️⃣ **MODIFICAR HORARIOS**

En `config.json` → sección `site.hours`:

```json
"hours": {
  "weekdays": "Lunes - Viernes: 8:00 - 15:00",
  "saturday": "Sábados: 8:00 - 14:00",
  "sunday": "Cerrado"
}
```

### 4️⃣ **AÑADIR UN USUARIO**

En `config.json` → array `users`:

```json
{
  "id": 6,
  "email": "nuevo@ejemplo.com",
  "password": "Password123!",
  "name": "Nombre Apellido",
  "role": "cliente",
  "active": true,
  "createdAt": "2024-04-11"
}
```

### 5️⃣ **CAMBIAR INFORMACIÓN DE CONTACTO**

```json
"site": {
  "name": "TU PANADERÍA",
  "phone": "+34 XXX XXX XXX",
  "email": "tu@email.com",
  "address": "Tu dirección completa"
}
```

### 6️⃣ **MODIFICAR BANNER**

En `config.json` → array `bannerSlides`:

```json
{
  "id": 4,
  "title": "Nueva Promoción",
  "subtitle": "Oferta especial",
  "description": "2x1 en todos los panes",
  "buttonText": "Ver Oferta",
  "buttonLink": "#productos",
  "background": "linear-gradient(135deg, #FF6B6B 0%, #FFD93D 100%)",
  "active": false
}
```

---

## 🎨 PERSONALIZACIÓN AVANZADA

### Cambiar Tipografía

En `config.json` → `theme`:

```json
"fontDisplay": "'Montserrat', sans-serif",
"fontBody": "'Open Sans', sans-serif"
```

Después, añade en `<head>` del HTML:
```html
<link href="https://fonts.googleapis.com/css2?family=Montserrat:wght@700;900&family=Open+Sans&display=swap" rel="stylesheet">
```

### Añadir Nueva Categoría

```json
{
  "id": "especiales",
  "name": "Especiales",
  "icon": "⭐",
  "description": "Productos de temporada",
  "color": "#FF6B9D"
}
```

Luego añade productos con `"category": "especiales"`.

---

## 👥 ROLES Y PERMISOS

### **Admin** (Administrador)
- ✅ Control total del sistema
- Credencial: `admin@senasgomez.es` / `Admin2024!`

### **Tienda** (Gestor de Tienda)
- ✅ Gestionar inventario
- ✅ Ver/gestionar pedidos
- Credencial: `tienda@senasgomez.es` / `Tienda2024!`

### **Maestro** (Maestro Panadero)
- ✅ Gestionar recetas
- ✅ Planificar producción
- Credencial: `delmi.soriano@senasgomez.es` / `Maestro2024!`

### **Cliente**
- ✅ Comprar productos
- ✅ Ver historial
- Credencial: `maria.garcia@email.com` / `Cliente123!`

### **Invitado**
- ✅ Solo ver productos

---

## 🔒 SEGURIDAD

### Validación de Contraseñas
Mínimo 8 caracteres, debe incluir:
- Mayúsculas
- Números
- Símbolos (!@#$%^&*)

### Protección de Permisos
```javascript
// Ejemplo: verificar permiso antes de acción
if (!Auth.hasPermission('editar_productos')) {
    UI.showToast('Sin permisos', 'error');
    return;
}
```

---

## 💾 DATOS DE EJEMPLO INCLUIDOS

### Productos: **16 productos**
- 5 Panes artesanales
- 5 Bollería
- 6 Pastelería

### Usuarios: **5 usuarios**
- 1 Admin
- 1 Gestor tienda
- 1 Maestro panadero
- 2 Clientes

### Categorías: **3 categorías**
- Panadería
- Bollería
- Pastelería

---

## 📊 ARQUITECTURA ESCALABLE

### Carga de Datos (Config Manager)

```javascript
// Cualquier componente puede acceder:
const productos = Config.products;
const usuario = Config.getUserByEmail('email@ejemplo.com');
const categoria = Config.getCategoryById('panaderia');
```

### Sistema de Eventos

```javascript
// Escuchar cambios en el carrito
Cart.onChange((items) => {
    console.log('Carrito actualizado:', items);
});

// Escuchar cambios en autenticación
Auth.onChange((user) => {
    console.log('Usuario cambió:', user);
});
```

---

## 🛠️ PARA DESARROLLADORES

### Añadir Nueva Funcionalidad

1. **Crear módulo** en `js/mi-modulo.js`
2. **Exportar clase**:
```javascript
class MiModulo {
    constructor() {
        // Inicialización
    }
}
const MiModulo = new MiModulo();
window.MiModulo = MiModulo;
```

3. **Cargar en HTML**:
```html
<script src="js/mi-modulo.js"></script>
```

4. **Usar en main.js**:
```javascript
await MiModulo.initialize();
```

### Persistencia de Datos

```javascript
// Guardar en localStorage
localStorage.setItem('clave', JSON.stringify(datos));

// Leer
const datos = JSON.parse(localStorage.getItem('clave'));
```

---

## 🎯 PRÓXIMOS PASOS PARA PRODUCCIÓN

### Backend Necesario
1. **API REST** (Node.js/PHP/Python)
   - Endpoints CRUD productos
   - Autenticación JWT
   - Base de datos SQL

2. **Pasarela de Pago**
   - Stripe / PayPal
   - Procesamiento seguro

3. **Sistema de Envíos**
   - Integración con transportistas
   - Tracking de pedidos

4. **Panel de Administración**
   - Dashboard completo
   - Estadísticas en tiempo real
   - Gestión de usuarios

### Optimizaciones
- Minificar CSS/JS
- Comprimir imágenes
- CDN para assets
- Cache de navegador
- Lazy loading

---

## 📱 RESPONSIVE BREAKPOINTS

- **Móvil**: < 768px
- **Tablet**: 768px - 968px
- **Desktop**: > 968px

Prueba con DevTools del navegador (F12 → Toggle device toolbar).

---

## 🐛 RESOLUCIÓN DE PROBLEMAS

### El carrito no guarda
- Verifica que localStorage esté habilitado
- Limpia caché del navegador

### Los productos no aparecen
- Revisa `config.json` (sintaxis JSON válida)
- Abre consola del navegador (F12) para ver errores

### Colores no cambian
- Verifica formato HEX correcto: `#RRGGBB`
- Recarga con Ctrl+Shift+R (fuerza recarga)

---

## 📞 CONTACTO

**Panadería SEÑAS GÓMEZ**
- 📍 Calle del Pan, 15, 09001 Burgos
- 📞 +34 947 123 456
- ✉️ info@senasgomez.es

---

## 📄 LICENCIA

Proyecto creado para **Panadería-Bollería SEÑAS GÓMEZ**
© 2024 - Todos los derechos reservados

---

## ✨ CHANGELOG

### v1.0.0 (11/04/2024)
- ✅ Sistema modular completo
- ✅ Config.json centralizado
- ✅ 5 roles de usuario
- ✅ Carrito funcional
- ✅ 16 productos de ejemplo
- ✅ Diseño responsive
- ✅ Animaciones suaves

---

**¡Disfruta de tu web escalable! 🍞✨**
