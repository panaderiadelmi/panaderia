// ============================================
// UI.JS - Utilidades de Interfaz
// ============================================

class UIManager {
    constructor() {
        this.toastContainer = null;
    }

    showToast(message, type = 'success') {
        if (!this.toastContainer) {
            this.toastContainer = document.getElementById('toastContainer');
        }

        const toast = document.createElement('div');
        toast.className = `toast ${type}`;
        toast.innerHTML = `
            <div style="font-weight: 600; margin-bottom: 4px;">
                ${type === 'success' ? '✓' : type === 'error' ? '✕' : '⚠'} 
                ${type === 'success' ? 'Éxito' : type === 'error' ? 'Error' : 'Aviso'}
            </div>
            <div style="font-size: 0.95rem;">${message}</div>
        `;

        this.toastContainer.appendChild(toast);

        setTimeout(() => {
            toast.style.animation = 'toastOut 0.3s ease-out forwards';
            setTimeout(() => toast.remove(), 300);
        }, 3000);
    }

    showAuthModal() {
        const modal = document.getElementById('authModal');
        if (modal) {
            modal.classList.add('show');
        }
    }

    hideAuthModal() {
        const modal = document.getElementById('authModal');
        if (modal) {
            modal.classList.remove('show');
        }
    }

    showLoading(message = 'Cargando...') {
        const overlay = document.createElement('div');
        overlay.id = 'loadingOverlay';
        overlay.style.cssText = `
            position: fixed;
            inset: 0;
            background: rgba(0,0,0,0.7);
            backdrop-filter: blur(5px);
            display: flex;
            align-items: center;
            justify-content: center;
            z-index: 3000;
        `;
        overlay.innerHTML = `
            <div style="background: white; padding: var(--space-xl); border-radius: var(--radius-lg); text-align: center;">
                <div style="font-size: 3rem; margin-bottom: var(--space-md);">⏳</div>
                <div style="font-family: var(--font-display); font-size: 1.3rem; color: var(--primary);">${message}</div>
            </div>
        `;
        document.body.appendChild(overlay);
    }

    hideLoading() {
        const overlay = document.getElementById('loadingOverlay');
        if (overlay) overlay.remove();
    }
}

const UI = new UIManager();
window.UI = UI;

// Animaciones CSS adicionales
const style = document.createElement('style');
style.textContent = `
    @keyframes toastOut {
        to {
            opacity: 0;
            transform: translateX(100px);
        }
    }
`;
document.head.appendChild(style);
