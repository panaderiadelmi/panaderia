// ============================================
// CONFIG.JS - Gestor de Configuración
// Carga config.json y expone datos globalmente
// ============================================

class ConfigManager {
    constructor() {
        this.config = null;
        this.loaded = false;
        this.listeners = [];
    }

    async load() {
        try {
            const response = await fetch('data/config.json');
            if (!response.ok) {
                throw new Error('No se pudo cargar la configuración');
            }
            this.config = await response.json();
            this.loaded = true;
            
            // Aplicar tema CSS
            this.applyTheme();
            
            // Notificar a los listeners
            this.listeners.forEach(callback => callback(this.config));
            
            return this.config;
        } catch (error) {
            console.error('Error al cargar configuración:', error);
            throw error;
        }
    }

    applyTheme() {
        if (!this.config?.theme) return;
        
        const root = document.documentElement;
        const theme = this.config.theme;
        
        root.style.setProperty('--primary', theme.primaryColor);
        root.style.setProperty('--secondary', theme.secondaryColor);
        root.style.setProperty('--accent', theme.accentColor);
        root.style.setProperty('--dark', theme.darkColor);
        root.style.setProperty('--light', theme.lightColor);
        root.style.setProperty('--cream', theme.creamColor);
        root.style.setProperty('--warm', theme.warmColor);
        root.style.setProperty('--success', theme.successColor);
        root.style.setProperty('--error', theme.errorColor);
        root.style.setProperty('--font-display', theme.fontDisplay);
        root.style.setProperty('--font-body', theme.fontBody);
    }

    onLoad(callback) {
        if (this.loaded) {
            callback(this.config);
        } else {
            this.listeners.push(callback);
        }
    }

    get site() {
        return this.config?.site || {};
    }

    get theme() {
        return this.config?.theme || {};
    }

    get bannerSlides() {
        return this.config?.bannerSlides || [];
    }

    get categories() {
        return this.config?.categories || [];
    }

    get products() {
        return this.config?.products || [];
    }

    get users() {
        return this.config?.users || [];
    }

    get roles() {
        return this.config?.roles || {};
    }

    get features() {
        return this.config?.features || [];
    }

    get testimonials() {
        return this.config?.testimonials || [];
    }

    getProductById(id) {
        return this.products.find(p => p.id === id);
    }

    getProductsByCategory(categoryId) {
        if (categoryId === 'all') return this.products;
        return this.products.filter(p => p.category === categoryId);
    }

    getCategoryById(id) {
        return this.categories.find(c => c.id === id);
    }

    getUserByEmail(email) {
        return this.users.find(u => u.email === email);
    }

    getRolePermissions(roleName) {
        return this.roles[roleName]?.permissions || [];
    }
}

// Crear instancia global
const Config = new ConfigManager();

// Exportar para uso en otros módulos
window.Config = Config;
