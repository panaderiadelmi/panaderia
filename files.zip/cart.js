// ============================================
// CART.JS - Sistema de Carrito de Compras
// ============================================

class CartManager {
    constructor() {
        this.items = [];
        this.listeners = [];
        this.load();
    }

    load() {
        const saved = localStorage.getItem('cart');
        if (saved) {
            try {
                this.items = JSON.parse(saved);
                this.notifyListeners();
            } catch (e) {
                this.items = [];
            }
        }
    }

    save() {
        localStorage.setItem('cart', JSON.stringify(this.items));
        this.notifyListeners();
    }

    addItem(productId, quantity = 1) {
        if (!Auth.requireLogin()) return false;

        const product = Config.getProductById(productId);
        if (!product) {
            UI.showToast('Producto no encontrado', 'error');
            return false;
        }

        if (!product.inStock || product.stock < quantity) {
            UI.showToast('Producto sin stock suficiente', 'error');
            return false;
        }

        const existing = this.items.find(item => item.productId === productId);
        
        if (existing) {
            const newQuantity = existing.quantity + quantity;
            if (newQuantity > product.stock) {
                UI.showToast(`Solo hay ${product.stock} unidades disponibles`, 'warning');
                return false;
            }
            existing.quantity = newQuantity;
        } else {
            this.items.push({
                productId,
                quantity,
                addedAt: new Date().toISOString()
            });
        }

        this.save();
        UI.showToast(`${product.name} añadido al carrito`, 'success');
        return true;
    }

    removeItem(productId) {
        this.items = this.items.filter(item => item.productId !== productId);
        this.save();
        UI.showToast('Producto eliminado del carrito', 'success');
    }

    updateQuantity(productId, quantity) {
        const item = this.items.find(item => item.productId === productId);
        if (!item) return;

        const product = Config.getProductById(productId);
        if (quantity > product.stock) {
            UI.showToast(`Solo hay ${product.stock} unidades disponibles`, 'warning');
            return;
        }

        if (quantity <= 0) {
            this.removeItem(productId);
        } else {
            item.quantity = quantity;
            this.save();
        }
    }

    clear() {
        this.items = [];
        this.save();
    }

    getItems() {
        return this.items.map(item => ({
            ...item,
            product: Config.getProductById(item.productId)
        }));
    }

    getTotal() {
        return this.getItems().reduce((total, item) => {
            const price = item.product.discount > 0 
                ? item.product.price * (1 - item.product.discount / 100)
                : item.product.price;
            return total + (price * item.quantity);
        }, 0);
    }

    getCount() {
        return this.items.reduce((count, item) => count + item.quantity, 0);
    }

    onChange(callback) {
        this.listeners.push(callback);
    }

    notifyListeners() {
        this.listeners.forEach(callback => callback(this.items));
    }
}

const Cart = new CartManager();
window.Cart = Cart;

// Event Listeners
document.addEventListener('DOMContentLoaded', () => {
    // Botón del carrito
    const cartBtn = document.getElementById('cartBtn');
    if (cartBtn) {
        cartBtn.addEventListener('click', () => {
            showCartModal();
        });
    }

    // Actualizar badge cuando cambie el carrito
    Cart.onChange(() => {
        updateCartBadge();
    });

    // Inicializar badge
    updateCartBadge();
});

function updateCartBadge() {
    const badge = document.getElementById('cartBadge');
    if (badge) {
        const count = Cart.getCount();
        badge.textContent = count;
        badge.style.display = count > 0 ? 'flex' : 'none';
    }
}

function showCartModal() {
    const items = Cart.getItems();
    
    if (items.length === 0) {
        showEmptyCart();
        return;
    }

    const modal = document.createElement('div');
    modal.className = 'modal show';
    modal.id = 'cartModal';
    modal.innerHTML = `
        <div class="modal-content" style="max-width: 700px;">
            <button class="modal-close">&times;</button>
            <div class="modal-header">
                <h2>🛒 Mi Carrito</h2>
            </div>
            
            <div style="max-height: 400px; overflow-y: auto; margin: var(--space-lg) 0;">
                ${items.map(item => renderCartItem(item)).join('')}
            </div>
            
            <div style="border-top: 3px solid var(--light); padding-top: var(--space-md);">
                <div style="display: flex; justify-content: space-between; align-items: center; margin-bottom: var(--space-md);">
                    <strong style="font-size: 1.5rem; color: var(--primary);">Total:</strong>
                    <strong style="font-size: 2rem; color: var(--primary); font-family: var(--font-display);">
                        ${Cart.getTotal().toFixed(2)}€
                    </strong>
                </div>
                
                <div style="display: grid; grid-template-columns: 1fr 2fr; gap: var(--space-sm);">
                    <button onclick="Cart.clear(); document.getElementById('cartModal').remove();" class="btn btn-outline">
                        Vaciar
                    </button>
                    <button onclick="checkout()" class="btn btn-primary">
                        Finalizar Compra
                    </button>
                </div>
            </div>
        </div>
    `;

    document.body.appendChild(modal);

    // Cerrar modal
    modal.querySelector('.modal-close').addEventListener('click', () => {
        modal.remove();
    });

    modal.addEventListener('click', (e) => {
        if (e.target === modal) modal.remove();
    });
}

function renderCartItem(item) {
    const product = item.product;
    const price = product.discount > 0 
        ? product.price * (1 - product.discount / 100)
        : product.price;
    
    return `
        <div style="
            display: grid;
            grid-template-columns: 80px 1fr auto auto;
            gap: var(--space-md);
            align-items: center;
            padding: var(--space-md);
            border-bottom: 1px solid var(--light);
        ">
            <div style="font-size: 3rem; text-align: center;">${product.icon}</div>
            
            <div>
                <h4 style="margin: 0; color: var(--primary);">${product.name}</h4>
                <p style="margin: 4px 0; color: #666; font-size: 0.9rem;">${price.toFixed(2)}€ / unidad</p>
                ${product.weight ? `<p style="margin: 0; font-size: 0.85rem; color: var(--accent);">${product.weight}</p>` : ''}
            </div>
            
            <div style="display: flex; align-items: center; gap: var(--space-xs);">
                <button onclick="Cart.updateQuantity(${product.id}, ${item.quantity - 1})" 
                    style="width: 32px; height: 32px; border: 2px solid var(--primary); background: white; border-radius: 6px; cursor: pointer; font-weight: bold; color: var(--primary);">−</button>
                <span style="min-width: 35px; text-align: center; font-weight: bold; font-size: 1.1rem; color: var(--primary);">${item.quantity}</span>
                <button onclick="Cart.updateQuantity(${product.id}, ${item.quantity + 1})" 
                    style="width: 32px; height: 32px; border: 2px solid var(--primary); background: white; border-radius: 6px; cursor: pointer; font-weight: bold; color: var(--primary);">+</button>
            </div>
            
            <div style="text-align: right;">
                <div style="font-weight: 700; font-size: 1.2rem; color: var(--primary); font-family: var(--font-display);">
                    ${(price * item.quantity).toFixed(2)}€
                </div>
                <button onclick="Cart.removeItem(${product.id}); showCartModal(); document.getElementById('cartModal').remove();" 
                    style="margin-top: 8px; background: var(--error); color: white; border: none; padding: 6px 12px; border-radius: 6px; cursor: pointer; font-size: 0.85rem;">
                    Eliminar
                </button>
            </div>
        </div>
    `;
}

function showEmptyCart() {
    const modal = document.createElement('div');
    modal.className = 'modal show';
    modal.innerHTML = `
        <div class="modal-content" style="text-align: center; max-width: 450px;">
            <button class="modal-close">&times;</button>
            <div style="font-size: 5rem; margin: var(--space-lg) 0;">🛒</div>
            <h2>Tu carrito está vacío</h2>
            <p style="color: #666; margin: var(--space-md) 0;">¡Explora nuestros productos artesanales!</p>
            <button onclick="this.closest('.modal').remove(); document.querySelector('[href=\\'#productos\\']').click();" class="btn btn-primary">
                Ver Productos
            </button>
        </div>
    `;

    document.body.appendChild(modal);
    
    modal.querySelector('.modal-close').addEventListener('click', () => {
        modal.remove();
    });
}

function checkout() {
    if (!Auth.hasPermission('comprar')) {
        UI.showToast('Debes iniciar sesión para comprar', 'error');
        document.getElementById('cartModal').remove();
        UI.showAuthModal();
        return;
    }

    // Simular proceso de compra
    UI.showToast('Procesando compra...', 'success');
    
    setTimeout(() => {
        const orderNumber = Math.floor(100000 + Math.random() * 900000);
        UI.showToast(`¡Pedido #${orderNumber} realizado con éxito!`, 'success');
        Cart.clear();
        document.getElementById('cartModal').remove();
    }, 1500);
}
