// ============================================
// MAIN.JS - Orquestador Principal
// ============================================

class BannerManager {
    constructor() {
        this.currentSlide = 0;
        this.slides = [];
        this.autoPlayInterval = null;
    }

    async initialize() {
        await Config.load();
        this.createSlides();
        this.createDots();
        this.startAutoPlay();
        this.setupControls();
    }

    createSlides() {
        const container = document.getElementById('bannerSlides');
        if (!container) return;

        this.slides = Config.bannerSlides;
        
        container.innerHTML = this.slides.map((slide, index) => `
            <div class="banner-slide ${index === 0 ? 'active' : ''}" 
                 style="background: ${slide.background}">
                <div class="slide-overlay"></div>
                <div class="slide-content">
                    <span class="subtitle">${slide.subtitle}</span>
                    <h2>${slide.title}</h2>
                    <p>${slide.description}</p>
                    <a href="${slide.buttonLink}" class="btn btn-primary">${slide.buttonText}</a>
                </div>
            </div>
        `).join('');
    }

    createDots() {
        const container = document.getElementById('dotsContainer');
        if (!container) return;

        container.innerHTML = this.slides.map((_, index) => 
            `<div class="banner-dot ${index === 0 ? 'active' : ''}" data-slide="${index}"></div>`
        ).join('');

        // Event listeners para dots
        container.querySelectorAll('.banner-dot').forEach((dot, index) => {
            dot.addEventListener('click', () => this.goToSlide(index));
        });
    }

    goToSlide(index) {
        const slides = document.querySelectorAll('.banner-slide');
        const dots = document.querySelectorAll('.banner-dot');

        slides[this.currentSlide].classList.remove('active');
        dots[this.currentSlide].classList.remove('active');

        this.currentSlide = (index + this.slides.length) % this.slides.length;

        slides[this.currentSlide].classList.add('active');
        dots[this.currentSlide].classList.add('active');
    }

    nextSlide() {
        this.goToSlide(this.currentSlide + 1);
    }

    prevSlide() {
        this.goToSlide(this.currentSlide - 1);
    }

    startAutoPlay() {
        this.autoPlayInterval = setInterval(() => this.nextSlide(), 5000);
    }

    stopAutoPlay() {
        if (this.autoPlayInterval) {
            clearInterval(this.autoPlayInterval);
        }
    }

    setupControls() {
        const prevBtn = document.getElementById('prevSlide');
        const nextBtn = document.getElementById('nextSlide');
        const banner = document.querySelector('.hero-banner');

        if (prevBtn) prevBtn.addEventListener('click', () => this.prevSlide());
        if (nextBtn) nextBtn.addEventListener('click', () => this.nextSlide());

        // Pausar en hover
        if (banner) {
            banner.addEventListener('mouseenter', () => this.stopAutoPlay());
            banner.addEventListener('mouseleave', () => this.startAutoPlay());
        }
    }
}

// ============================================
// INICIALIZACIÓN DE LA APLICACIÓN
// ============================================

async function initializeApp() {
    try {
        UI.showLoading('Cargando panadería...');

        // 1. Cargar configuración
        await Config.load();

        // 2. Cargar contenido dinámico
        loadSiteInfo();
        loadCategories();
        loadFeatures();
        loadContactInfo();
        loadFooter();

        // 3. Inicializar componentes
        const banner = new BannerManager();
        await banner.initialize();

        await Products.initialize();

        // 4. Smooth scroll para navegación
        setupSmoothScroll();

        // 5. Scroll spy para navegación activa
        setupScrollSpy();

        UI.hideLoading();
        
    } catch (error) {
        console.error('Error al inicializar:', error);
        UI.hideLoading();
        UI.showToast('Error al cargar la aplicación', 'error');
    }
}

function loadSiteInfo() {
    const site = Config.site;
    
    document.getElementById('siteName').textContent = site.name;
    document.getElementById('siteTagline').textContent = site.tagline;
    document.getElementById('siteDescription').textContent = site.description;
}

function loadCategories() {
    const grid = document.getElementById('categoriesGrid');
    if (!grid) return;

    grid.innerHTML = Config.categories.map(cat => {
        const count = Config.getProductsByCategory(cat.id).length;
        return `
            <div class="category-card" style="--category-color: ${cat.color}" 
                 onclick="document.querySelector('[data-category=\\'${cat.id}\\']').click(); document.querySelector('#productos').scrollIntoView({behavior: 'smooth'});">
                <div class="category-icon">${cat.icon}</div>
                <h3>${cat.name}</h3>
                <p>${cat.description}</p>
                <p class="category-count">${count} productos</p>
            </div>
        `;
    }).join('');
}

function loadFeatures() {
    const grid = document.getElementById('featuresGrid');
    if (!grid) return;

    grid.innerHTML = Config.features.map(feature => `
        <div class="feature-card">
            <div class="feature-icon">${feature.icon}</div>
            <h3>${feature.title}</h3>
            <p>${feature.description}</p>
        </div>
    `).join('');

    // Maestro panadero
    const site = Config.site;
    document.getElementById('masterBakerName').textContent = site.masterBaker;
    document.getElementById('masterBakerExp').textContent = `Desde ${site.established}`;
}

function loadContactInfo() {
    const container = document.getElementById('contactInfo');
    if (!container) return;

    const site = Config.site;
    container.innerHTML = `
        <div class="info-item">
            <div class="info-icon">📍</div>
            <div class="info-content">
                <h4>Dirección</h4>
                <p>${site.address}</p>
            </div>
        </div>
        <div class="info-item">
            <div class="info-icon">📞</div>
            <div class="info-content">
                <h4>Teléfono</h4>
                <p>${site.phone}</p>
            </div>
        </div>
        <div class="info-item">
            <div class="info-icon">✉️</div>
            <div class="info-content">
                <h4>Email</h4>
                <p>${site.email}</p>
            </div>
        </div>
        <div class="info-item">
            <div class="info-icon">🕒</div>
            <div class="info-content">
                <h4>Horario</h4>
                <p>${site.hours.weekdays}</p>
                <p>${site.hours.saturday}</p>
                <p>${site.hours.sunday}</p>
            </div>
        </div>
    `;
}

function loadFooter() {
    const site = Config.site;
    
    document.getElementById('footerSiteName').textContent = site.name;
    document.getElementById('footerDescription').textContent = `${site.tagline} - ${site.description}`;
    document.getElementById('footerCopyright').textContent = site.name;
    document.getElementById('currentYear').textContent = new Date().getFullYear();

    // Horarios
    const hoursContainer = document.getElementById('footerHours');
    if (hoursContainer) {
        hoursContainer.innerHTML = `
            <li>${site.hours.weekdays}</li>
            <li>${site.hours.saturday}</li>
            <li>${site.hours.sunday}</li>
        `;
    }

    // Contacto
    const contactContainer = document.getElementById('footerContact');
    if (contactContainer) {
        contactContainer.innerHTML = `
            <li>📍 ${site.address}</li>
            <li>📞 ${site.phone}</li>
            <li>✉️ ${site.email}</li>
        `;
    }

    // Redes sociales
    const socialContainer = document.getElementById('footerSocial');
    if (socialContainer && site.social) {
        socialContainer.innerHTML = `
            ${site.social.facebook ? `<a href="${site.social.facebook}" class="social-link" target="_blank" title="Facebook">📘</a>` : ''}
            ${site.social.instagram ? `<a href="https://instagram.com/${site.social.instagram}" class="social-link" target="_blank" title="Instagram">📷</a>` : ''}
            ${site.social.whatsapp ? `<a href="https://wa.me/${site.social.whatsapp.replace(/[^0-9]/g, '')}" class="social-link" target="_blank" title="WhatsApp">💬</a>` : ''}
        `;
    }
}

function setupSmoothScroll() {
    document.querySelectorAll('a[href^="#"]').forEach(anchor => {
        anchor.addEventListener('click', function (e) {
            e.preventDefault();
            const target = document.querySelector(this.getAttribute('href'));
            if (target) {
                target.scrollIntoView({
                    behavior: 'smooth',
                    block: 'start'
                });
            }
        });
    });
}

function setupScrollSpy() {
    const sections = document.querySelectorAll('section[id]');
    const navLinks = document.querySelectorAll('.main-nav a');

    window.addEventListener('scroll', () => {
        let current = '';
        
        sections.forEach(section => {
            const sectionTop = section.offsetTop;
            const sectionHeight = section.clientHeight;
            if (scrollY >= (sectionTop - 200)) {
                current = section.getAttribute('id');
            }
        });

        navLinks.forEach(link => {
            link.classList.remove('active');
            if (link.getAttribute('href') === `#${current}`) {
                link.classList.add('active');
            }
        });
    });
}

// Formulario de contacto
document.addEventListener('DOMContentLoaded', () => {
    const contactForm = document.getElementById('contactForm');
    if (contactForm) {
        contactForm.addEventListener('submit', (e) => {
            e.preventDefault();
            UI.showToast('Mensaje enviado correctamente', 'success');
            contactForm.reset();
        });
    }
});

// ============================================
// INICIAR APLICACIÓN
// ============================================

document.addEventListener('DOMContentLoaded', initializeApp);
