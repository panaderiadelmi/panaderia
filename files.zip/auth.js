// ============================================
// AUTH.JS - Sistema de Autenticación
// ============================================

class AuthManager {
    constructor() {
        this.currentUser = null;
        this.listeners = [];
        this.init();
    }

    init() {
        // Cargar sesión guardada
        const savedSession = localStorage.getItem('session');
        if (savedSession) {
            try {
                this.currentUser = JSON.parse(savedSession);
                this.notifyListeners();
            } catch (e) {
                localStorage.removeItem('session');
            }
        }
    }

    async login(email, password) {
        await Config.load(); // Asegurar que config esté cargado
        
        const user = Config.getUserByEmail(email);
        
        if (!user) {
            throw new Error('Usuario no encontrado');
        }

        if (user.password !== password) {
            throw new Error('Contraseña incorrecta');
        }

        if (!user.active) {
            throw new Error('Usuario inactivo');
        }

        // Crear sesión
        this.currentUser = {
            id: user.id,
            name: user.name,
            email: user.email,
            role: user.role,
            permissions: Config.getRolePermissions(user.role),
            loginTime: new Date().toISOString()
        };

        // Guardar sesión
        localStorage.setItem('session', JSON.stringify(this.currentUser));
        
        // Notificar cambio
        this.notifyListeners();

        return this.currentUser;
    }

    async register(userData) {
        await Config.load();

        // Validar email único
        const existingUser = Config.getUserByEmail(userData.email);
        if (existingUser) {
            throw new Error('Este email ya está registrado');
        }

        // Validar contraseña
        if (!this.validatePassword(userData.password)) {
            throw new Error('La contraseña debe tener al menos 8 caracteres, incluir mayúsculas, números y símbolos');
        }

        // En producción, aquí harías una llamada al backend
        // Por ahora simulamos el registro
        const newUser = {
            id: Date.now(),
            name: userData.name,
            email: userData.email,
            password: userData.password, // En producción: hash
            role: 'cliente',
            active: true,
            createdAt: new Date().toISOString()
        };

        // Auto-login después del registro
        return await this.login(userData.email, userData.password);
    }

    loginAsGuest() {
        this.currentUser = {
            id: 'guest',
            name: 'Invitado',
            email: '',
            role: 'invitado',
            permissions: Config.getRolePermissions('invitado'),
            loginTime: new Date().toISOString()
        };

        localStorage.setItem('session', JSON.stringify(this.currentUser));
        this.notifyListeners();

        return this.currentUser;
    }

    logout() {
        this.currentUser = null;
        localStorage.removeItem('session');
        localStorage.removeItem('cart'); // Limpiar carrito
        this.notifyListeners();
    }

    isLoggedIn() {
        return this.currentUser !== null;
    }

    isGuest() {
        return this.currentUser?.role === 'invitado';
    }

    hasPermission(permission) {
        if (!this.currentUser) return false;
        
        const permissions = this.currentUser.permissions;
        
        // Admin tiene todos los permisos
        if (permissions.includes('*')) return true;
        
        return permissions.includes(permission);
    }

    requireLogin() {
        if (!this.isLoggedIn() || this.isGuest()) {
            UI.showAuthModal();
            return false;
        }
        return true;
    }

    requirePermission(permission) {
        if (!this.hasPermission(permission)) {
            UI.showToast(`No tienes permiso para: ${permission}`, 'error');
            return false;
        }
        return true;
    }

    validatePassword(password) {
        // Al menos 8 caracteres, 1 mayúscula, 1 número, 1 símbolo
        const minLength = password.length >= 8;
        const hasUpper = /[A-Z]/.test(password);
        const hasNumber = /[0-9]/.test(password);
        const hasSymbol = /[!@#$%^&*]/.test(password);
        
        return minLength && hasUpper && hasNumber && hasSymbol;
    }

    onChange(callback) {
        this.listeners.push(callback);
    }

    notifyListeners() {
        this.listeners.forEach(callback => callback(this.currentUser));
    }

    getCurrentUser() {
        return this.currentUser;
    }

    getUserName() {
        return this.currentUser?.name || 'Invitado';
    }

    getUserRole() {
        return this.currentUser?.role || 'invitado';
    }
}

// Crear instancia global
const Auth = new AuthManager();
window.Auth = Auth;

// ============================================
// EVENT LISTENERS - UI de Autenticación
// ============================================

document.addEventListener('DOMContentLoaded', () => {
    // Botón de usuario
    const userBtn = document.getElementById('userBtn');
    if (userBtn) {
        userBtn.addEventListener('click', () => {
            if (Auth.isLoggedIn()) {
                showUserMenu();
            } else {
                UI.showAuthModal();
            }
        });
    }

    // Tabs de auth
    const authTabs = document.querySelectorAll('.auth-tab');
    authTabs.forEach(tab => {
        tab.addEventListener('click', () => {
            const tabName = tab.dataset.tab;
            switchAuthTab(tabName);
        });
    });

    // Login form
    const loginForm = document.getElementById('loginForm');
    if (loginForm) {
        loginForm.addEventListener('submit', async (e) => {
            e.preventDefault();
            
            const email = document.getElementById('loginEmail').value;
            const password = document.getElementById('loginPassword').value;

            try {
                await Auth.login(email, password);
                UI.hideAuthModal();
                UI.showToast(`¡Bienvenido ${Auth.getUserName()}!`, 'success');
            } catch (error) {
                UI.showToast(error.message, 'error');
            }
        });
    }

    // Register form
    const registerForm = document.getElementById('registerForm');
    if (registerForm) {
        registerForm.addEventListener('submit', async (e) => {
            e.preventDefault();

            const name = document.getElementById('regName').value;
            const email = document.getElementById('regEmail').value;
            const password = document.getElementById('regPassword').value;
            const passwordConfirm = document.getElementById('regPasswordConfirm').value;

            if (password !== passwordConfirm) {
                UI.showToast('Las contraseñas no coinciden', 'error');
                return;
            }

            try {
                await Auth.register({ name, email, password });
                UI.hideAuthModal();
                UI.showToast(`¡Registro exitoso! Bienvenido ${name}`, 'success');
            } catch (error) {
                UI.showToast(error.message, 'error');
            }
        });
    }

    // Guest login
    const guestBtn = document.getElementById('guestLoginBtn');
    if (guestBtn) {
        guestBtn.addEventListener('click', () => {
            Auth.loginAsGuest();
            UI.hideAuthModal();
            UI.showToast('Navegando como invitado', 'success');
        });
    }

    // Cerrar modales
    const closeAuthModal = document.getElementById('closeAuthModal');
    if (closeAuthModal) {
        closeAuthModal.addEventListener('click', () => {
            UI.hideAuthModal();
        });
    }

    // Actualizar UI cuando cambie el estado de auth
    Auth.onChange((user) => {
        updateAuthUI(user);
    });

    // Inicializar UI
    updateAuthUI(Auth.getCurrentUser());
});

function switchAuthTab(tabName) {
    // Actualizar tabs
    document.querySelectorAll('.auth-tab').forEach(tab => {
        tab.classList.toggle('active', tab.dataset.tab === tabName);
    });

    // Actualizar formularios
    document.querySelectorAll('.auth-form').forEach(form => {
        form.classList.toggle('active', form.id === `${tabName}Form`);
    });

    // Actualizar título
    const title = tabName === 'login' ? 'Iniciar Sesión' : 'Registrarse';
    document.getElementById('modalTitle').textContent = title;
}

function updateAuthUI(user) {
    const userBtn = document.getElementById('userBtn');
    if (!userBtn) return;

    if (user) {
        // Usuario logueado - cambiar icono
        userBtn.innerHTML = `
            <svg width="24" height="24" viewBox="0 0 24 24" fill="currentColor" stroke="none">
                <path d="M20 21v-2a4 4 0 0 0-4-4H8a4 4 0 0 0-4 4v2"></path>
                <circle cx="12" cy="7" r="4"></circle>
            </svg>
        `;
        userBtn.title = `${user.name} (${user.role})`;
    } else {
        // No logueado - icono normal
        userBtn.innerHTML = `
            <svg width="24" height="24" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2">
                <path d="M20 21v-2a4 4 0 0 0-4-4H8a4 4 0 0 0-4 4v2"></path>
                <circle cx="12" cy="7" r="4"></circle>
            </svg>
        `;
        userBtn.title = 'Iniciar sesión';
    }
}

function showUserMenu() {
    const user = Auth.getCurrentUser();
    if (!user) return;

    const menu = document.createElement('div');
    menu.className = 'user-menu';
    menu.style.cssText = `
        position: fixed;
        top: 90px;
        right: 20px;
        background: white;
        border-radius: 12px;
        box-shadow: var(--shadow-xl);
        padding: var(--space-md);
        z-index: 2500;
        min-width: 250px;
        animation: modalIn 0.2s ease-out;
    `;

    menu.innerHTML = `
        <div style="padding-bottom: var(--space-md); border-bottom: 2px solid var(--light);">
            <div style="font-weight: 700; font-size: 1.1rem; color: var(--primary);">${user.name}</div>
            <div style="font-size: 0.85rem; color: #666; margin-top: 4px;">${user.email || 'Invitado'}</div>
            <div style="font-size: 0.8rem; color: var(--secondary); margin-top: 4px; text-transform: uppercase; letter-spacing: 1px;">${user.role}</div>
        </div>
        <div style="padding: var(--space-md) 0;">
            ${getMenuOptions(user.role)}
        </div>
        <button id="logoutBtn" style="
            width: 100%;
            padding: var(--space-sm);
            background: var(--error);
            color: white;
            border: none;
            border-radius: 8px;
            font-weight: 600;
            cursor: pointer;
            transition: var(--transition-base);
        ">
            Cerrar Sesión
        </button>
    `;

    document.body.appendChild(menu);

    // Logout
    document.getElementById('logoutBtn').addEventListener('click', () => {
        Auth.logout();
        menu.remove();
        UI.showToast('Sesión cerrada', 'success');
    });

    // Cerrar al hacer click fuera
    setTimeout(() => {
        const closeMenu = (e) => {
            if (!menu.contains(e.target) && e.target !== document.getElementById('userBtn')) {
                menu.remove();
                document.removeEventListener('click', closeMenu);
            }
        };
        document.addEventListener('click', closeMenu);
    }, 100);
}

function getMenuOptions(role) {
    const options = {
        admin: [
            { text: '📊 Panel Administrador', action: 'alert("Panel de administrador")' },
            { text: '👥 Gestión de Usuarios', action: 'alert("Gestión de usuarios")' },
            { text: '📦 Gestión de Productos', action: 'alert("Gestión de productos")' },
            { text: '⚙️ Configuración', action: 'alert("Configuración del sistema")' }
        ],
        tienda: [
            { text: '📊 Panel de Tienda', action: 'alert("Panel de tienda")' },
            { text: '📦 Gestionar Inventario', action: 'alert("Gestionar inventario")' },
            { text: '📋 Ver Pedidos', action: 'alert("Ver pedidos")' },
            { text: '📈 Reportes', action: 'alert("Ver reportes")' }
        ],
        maestro: [
            { text: '📊 Panel de Producción', action: 'alert("Panel de producción")' },
            { text: '📖 Gestionar Recetas', action: 'alert("Gestionar recetas")' },
            { text: '📋 Planificar Producción', action: 'alert("Planificar producción")' }
        ],
        cliente: [
            { text: '🛍️ Mis Pedidos', action: 'alert("Ver mis pedidos")' },
            { text: '⭐ Mis Favoritos', action: 'alert("Ver favoritos")' },
            { text: '👤 Mi Cuenta', action: 'alert("Gestionar cuenta")' }
        ],
        invitado: [
            { text: '🔑 Iniciar Sesión', action: 'UI.showAuthModal(); document.querySelector(".user-menu").remove();' }
        ]
    };

    return (options[role] || []).map(opt => `
        <button onclick="${opt.action}" style="
            width: 100%;
            padding: var(--space-sm);
            background: transparent;
            border: none;
            text-align: left;
            cursor: pointer;
            border-radius: 6px;
            transition: var(--transition-base);
            margin-bottom: 4px;
        " onmouseover="this.style.background='var(--light)'" 
           onmouseout="this.style.background='transparent'">
            ${opt.text}
        </button>
    `).join('');
}
