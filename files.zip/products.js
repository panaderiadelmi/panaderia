// ============================================
// PRODUCTS.JS - Gestión de Productos
// ============================================

class ProductsManager {
    constructor() {
        this.currentCategory = 'all';
        this.currentSort = 'default';
        this.visibleCount = 9;
    }

    async initialize() {
        await Config.load();
        this.renderProducts();
        this.setupFilters();
    }

    getFilteredProducts() {
        let products = this.currentCategory === 'all' 
            ? Config.products 
            : Config.getProductsByCategory(this.currentCategory);

        // Ordenar
        switch (this.currentSort) {
            case 'price-asc':
                products.sort((a, b) => a.price - b.price);
                break;
            case 'price-desc':
                products.sort((a, b) => b.price - a.price);
                break;
            case 'name':
                products.sort((a, b) => a.name.localeCompare(b.name));
                break;
        }

        return products;
    }

    renderProducts() {
        const grid = document.getElementById('productsGrid');
        if (!grid) return;

        const products = this.getFilteredProducts();
        const visible = products.slice(0, this.visibleCount);

        grid.innerHTML = visible.map(product => this.renderProductCard(product)).join('');

        // Actualizar botón "Ver más"
        const loadMoreBtn = document.getElementById('loadMoreBtn');
        if (loadMoreBtn) {
            loadMoreBtn.style.display = visible.length < products.length ? 'block' : 'none';
        }
    }

    renderProductCard(product) {
        const category = Config.getCategoryById(product.category);
        const discountPrice = product.discount > 0 
            ? product.price * (1 - product.discount / 100)
            : product.price;

        return `
            <div class="product-card" style="--category-color: ${category?.color || 'var(--primary)'}">
                <div class="product-image">
                    ${product.icon}
                    ${product.discount > 0 ? `<span class="product-badge discount">-${product.discount}%</span>` : ''}
                    ${!product.inStock ? '<span class="product-badge">Agotado</span>' : ''}
                </div>
                <div class="product-info">
                    <div class="product-category">${category?.name || ''}</div>
                    <h3>${product.name}</h3>
                    <p class="product-description">${product.description}</p>
                    <div class="product-meta">
                        <span>⚖️ ${product.weight}</span>
                        ${product.inStock ? `<span>✓ ${product.stock} unidades</span>` : ''}
                    </div>
                    <div class="product-footer">
                        <div>
                            ${product.discount > 0 ? `<span class="price-old">${product.price.toFixed(2)}€</span>` : ''}
                            <div class="product-price">${discountPrice.toFixed(2)}€</div>
                        </div>
                        <button class="btn-add-cart" 
                                onclick="Cart.addItem(${product.id})" 
                                ${!product.inStock ? 'disabled' : ''}>
                            ${product.inStock ? 'Añadir' : 'Agotado'}
                        </button>
                    </div>
                </div>
            </div>
        `;
    }

    setupFilters() {
        // Filtros de categoría
        document.querySelectorAll('.filter-btn').forEach(btn => {
            btn.addEventListener('click', () => {
                document.querySelectorAll('.filter-btn').forEach(b => b.classList.remove('active'));
                btn.classList.add('active');
                this.currentCategory = btn.dataset.category;
                this.visibleCount = 9;
                this.renderProducts();
            });
        });

        // Ordenar
        const sortSelect = document.getElementById('sortSelect');
        if (sortSelect) {
            sortSelect.addEventListener('change', (e) => {
                this.currentSort = e.target.value;
                this.renderProducts();
            });
        }

        // Ver más
        const loadMoreBtn = document.getElementById('loadMoreBtn');
        if (loadMoreBtn) {
            loadMoreBtn.addEventListener('click', () => {
                this.visibleCount += 6;
                this.renderProducts();
            });
        }
    }
}

const Products = new ProductsManager();
window.Products = Products;
